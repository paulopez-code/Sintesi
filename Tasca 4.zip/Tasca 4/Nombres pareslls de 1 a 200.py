Nombre = 2
# Aquestes linies imprimiran els nombres parells de l'1 al 200 dintre d'un bucle
while Nombre <= 200:
    print(Nombre)
    Nombre += 2