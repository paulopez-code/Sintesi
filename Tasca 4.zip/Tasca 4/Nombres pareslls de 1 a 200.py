for x in range(1, 201):
    if x % 2 == 0:
        print(x)