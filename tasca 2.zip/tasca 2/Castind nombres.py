Primer_Nombre = float (input("Escriu el teu nombre: "))
Segon_Nombre = float (input("Escriu un altre nombre: "))
Suma = Primer_Nombre + Segon_Nombre
print ("La suma dels dos nombres és:", round(Suma))