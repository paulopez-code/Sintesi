def main():
    # Aquesta linia escriu "Hola, Mundo!" a la pantalla
    print("Hola, Mundo!")


if __name__ == "__main__":
    main()