def HolaMundo():
    # Aquesta linia escriu "Hola, Mundo!" a la pantalla
    print("Hola, Mundo!")


if __name__ == "__HolaMundo__":
    HolaMundo()