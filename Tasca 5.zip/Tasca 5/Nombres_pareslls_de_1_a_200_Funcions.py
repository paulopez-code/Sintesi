def nombres_parells():
    for x in range(1, 201):
        if x % 2 == 0:
            print(x)
if __name__ == "__nombres_parells__":
    nombres_parells()